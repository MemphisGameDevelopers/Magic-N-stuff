#if UNITY_EDITOR
@CustomEditor(setupAdvancedFoliageShader)
class setupAdvancedFoliageShaderEditor extends Editor
{

	override function OnInspectorGUI ()
	
	
	{
		var myCol : Color = Color.green;
		var myFoldoutStyle : GUIStyle = new GUIStyle(EditorStyles.foldout);
		myFoldoutStyle.fontStyle = FontStyle.Bold;	
		GUILayout.Space(6);

	//	Wind settings
		GUILayout.Space(4);
		EditorGUILayout.BeginVertical("Box");
		GUI.color = myCol;
		target.FoldWind = EditorGUILayout.Foldout(target.FoldWind," Wind Settings", myFoldoutStyle );
		GUI.color = Color.white;
		if (target.FoldWind) {
			GUILayout.Space(2);
			GUI.color = myCol;
			EditorGUILayout.LabelField("Overall Wind Settings");
			GUI.color = Color.white;
			
			//toolTip = "myToolTip";
			//EditorGUILayout.LabelField(new GUIContent("Wind Direction (xyz) Strength (w)", toolTip), GUILayout.Height(14));
			target.Wind = EditorGUILayout.Vector4Field("Wind Direction (xyz) Strength (w)", target.Wind);
			target.WindFrequency = EditorGUILayout.Slider("Wind Frequency", target.WindFrequency, 0.0, 10.0);
			GUILayout.Space(4);
			GUI.color = myCol;
			GUILayout.Label ("Wind Settings for the Foliage Shaders");
			GUI.color = Color.white;
			target.WaveSizeFoliageShader = EditorGUILayout.Slider("Wave Size Foliage", target.WaveSizeFoliageShader, 0.0, 50.0);
			GUILayout.Space(4);
			GUI.color = myCol;
			GUILayout.Label ("Wind Settings for the Grass Shaders");
			GUI.color = Color.white;
			target.WindMultiplierForGrassshader = EditorGUILayout.Slider("Wind Multiplier Grass", target.WindMultiplierForGrassshader, 0.0, 5.0);
			target.WaveSizeForGrassshader = EditorGUILayout.Slider("Wave Size Grass", target.WaveSizeForGrassshader, 0.0, 50.0);
		}
		EditorGUILayout.EndVertical();
		
	//	Rain Settings
		GUILayout.Space(4);
		EditorGUILayout.BeginVertical("Box");
		GUI.color = myCol;
		target.FoldRain = EditorGUILayout.Foldout(target.FoldRain," Rain Settings", myFoldoutStyle );
		GUI.color = Color.white;
		if (target.FoldRain) {
			target.RainAmount = EditorGUILayout.Slider("Rain Amount", target.RainAmount, 0.0, 1.0);
			target.SpecPower = EditorGUILayout.Slider("Specular Power", target.SpecPower, 0.0, 8.0);
		}
		EditorGUILayout.EndVertical();
		
	//	Terrain Detail Vegetation Settings
		GUILayout.Space(4);
		EditorGUILayout.BeginVertical("Box");
		GUI.color = myCol;
		target.FoldVegTerrain = EditorGUILayout.Foldout(target.FoldVegTerrain," Terrain Detail Vegetation Settings", myFoldoutStyle );
		GUI.color = Color.white;
		if (target.FoldVegTerrain) {
			GUILayout.Space(2);
			target.VertexLitAlphaCutOff = EditorGUILayout.Slider("Alpha Cut Off", target.VertexLitAlphaCutOff, 0.1, 1.0);
			target.VertexLitTranslucencyColor = EditorGUILayout.ColorField ("Translucency Color", target.VertexLitTranslucencyColor);
			target.VertexLitTranslucencyViewDependency = EditorGUILayout.Slider("Translucency View Dependency", target.VertexLitTranslucencyViewDependency, 0.1, 1.0);
			target.VertexLitShadowStrength = EditorGUILayout.Slider("Shadow Strength", target.VertexLitShadowStrength, 0.1, 1.0);
			target.VertexLitShininess = EditorGUILayout.Slider("Shininess", target.VertexLitShininess, 0.03, 1.0);
		}
		EditorGUILayout.EndVertical();
		
	//	Tree and Billboard settings
		GUILayout.Space(4);
		EditorGUILayout.BeginVertical("Box");
		GUI.color = myCol;
		target.FoldBillboard = EditorGUILayout.Foldout(target.FoldBillboard," Grass, Tree and Billboard Settings", myFoldoutStyle );
		GUI.color = Color.white;
		if (target.FoldBillboard) {
			GUILayout.Space(2);
			// General Billboard settings
			GUI.color = myCol;
			EditorGUILayout.LabelField("Sync Settings to Terrain");
			GUI.color = Color.white;
			
			
			EditorGUILayout.BeginHorizontal();
			target.AutoSyncToTerrain = EditorGUILayout.Toggle("", target.AutoSyncToTerrain, GUILayout.Width(14) );
			EditorGUILayout.LabelField("Automatically sync with Terrain");
			EditorGUILayout.EndHorizontal();
			
			
			
			if(target.AutoSyncToTerrain) {
				target.SyncedTerrain = EditorGUILayout.ObjectField("Specify Terrain", target.SyncedTerrain, typeof(Terrain), true);
				if(target.SyncedTerrain != null){
					GUI.enabled = false;
				}
			}
			GUILayout.Space(4);
			target.DetailDistanceForGrassShader = EditorGUILayout.Slider("Detail Distance Grass", target.DetailDistanceForGrassShader, 0.0, 400.0);
			target.BillboardStart = EditorGUILayout.Slider("Billboard Start", target.BillboardStart, 0.0, 1000.0);
			
			if(target.TreeBillboardShadows){
					GUI.enabled = true;
			}
			target.BillboardFadeLenght = EditorGUILayout.Slider("Fade Length", target.BillboardFadeLenght, 0.0, 30.0);
			

			if(target.AutoSyncToTerrain) {
				GUI.enabled = true;
			}
			
			// Tree and Billboard Render settings
			GUILayout.Space(4);
			GUI.color = myCol;
			EditorGUILayout.LabelField("Tree and Billboard Render Settings");
			GUI.color = Color.white;
			EditorGUILayout.BeginHorizontal();
			target.TreeShadowDissolve = EditorGUILayout.Toggle("", target.TreeShadowDissolve, GUILayout.Width(14) );
			EditorGUILayout.LabelField("Enable Dissolve Shadows for Trees");
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(4);
			if (target.TreeShadowDissolve) {
				target.TreeBillboardShadows = false;
			}
			
			EditorGUILayout.BeginHorizontal();
			target.TreeBillboardShadows = EditorGUILayout.Toggle("", target.TreeBillboardShadows, GUILayout.Width(14) );
			EditorGUILayout.LabelField("Enable Shadows casted by Billboards");
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(4);
			
			if (target.TreeBillboardShadows) {
				target.TreeShadowDissolve = false;
				EditorGUILayout.HelpBox("Please make sure that you have assigned and/or enabled the corresponding shaders.", MessageType.Warning, true);
				GUILayout.Space(4);
				//
				ResetBillboardFadeLength();
			}
			
			else {
				RestoreBillboardFadeLength(target.BillboardFadeLenght);
			}
			
			target.BillboardFadeOutLength = EditorGUILayout.Slider("Billboard Fade Out Length", target.BillboardFadeOutLength, 10, 100);
			EditorGUILayout.BeginHorizontal();
			target.BillboardAdjustToCamera = EditorGUILayout.Toggle("", target.BillboardAdjustToCamera, GUILayout.Width(14) );
			EditorGUILayout.LabelField("Align Billboards to Camera");
			EditorGUILayout.EndHorizontal();
			if (target.BillboardAdjustToCamera) {
				target.BillboardAngleLimit = EditorGUILayout.Slider("Angle Limit", target.BillboardAngleLimit, 10, 90);
			}
			
			// Billboard RenderTex settings
			GUILayout.Space(4);
			GUI.color = myCol;
			EditorGUILayout.LabelField("Billboard Texture Settings");
			GUI.color = Color.white;
			target.BillboardTranslucencyFactor = EditorGUILayout.Slider("Translucency Factor", target.BillboardTranslucencyFactor, 1.0, 3.0);
			target.BillboardLeafsLightingFactor = EditorGUILayout.Slider("Leaf Lighting Factor", target.BillboardLeafsLightingFactor, 1.0, 3.0);
			target.BillboardLeafsContrast = EditorGUILayout.Slider("Leaf Contrast", target.BillboardLeafsContrast, .5, 2.0);
			//
			GUILayout.Space(4);
			EditorGUILayout.BeginHorizontal();
				EditorGUILayout.LabelField("");
				if ( GUILayout.Button( "Reset", GUILayout.MaxWidth(50) ) ) {
					target.BillboardTranslucencyFactor = 2.0;
					target.BillboardLeafsLightingFactor = 2.0;
					target.BillboardLeafsContrast = 1.0;
				}
			EditorGUILayout.EndHorizontal();
			
			
			// "Shaded" Billboard settings
			GUILayout.Space(4);
			GUI.color = myCol;
			EditorGUILayout.LabelField("Shaded Billboard Settings");
			GUI.color = Color.white;
			target.BillboardLightReference = EditorGUILayout.ObjectField("Light Reference", target.BillboardLightReference, typeof(GameObject), true);
			GUI.enabled = false;
			target.BillboardShadowColor = EditorGUILayout.ColorField ("Shadow Color", target.BillboardShadowColor);
			GUI.enabled = true;
			target.BillboardAmbientLightFactor = EditorGUILayout.Slider("Ambient Light Factor", target.BillboardAmbientLightFactor, 0.0, 4.0);
			target.BillboardAmbientLightDesaturationFactor = EditorGUILayout.Slider("Ambient Light Desaturation Factor", target.BillboardAmbientLightDesaturationFactor, 0.0, 2.0);
		}
		EditorGUILayout.EndVertical();
		
	//	Camera Layer Culling Settings
		GUILayout.Space(4);
		EditorGUILayout.BeginVertical("Box");
		GUI.color = myCol;
		target.FoldCulling = EditorGUILayout.Foldout(target.FoldCulling," Camera Culling Settings", myFoldoutStyle );
		GUI.color = Color.white;
		if (target.FoldCulling) {
			EditorGUILayout.BeginHorizontal();
			target.EnableCameraLayerCulling = EditorGUILayout.Toggle("", target.EnableCameraLayerCulling, GUILayout.Width(14) );
			EditorGUILayout.LabelField("Enable Layer Culling");
			EditorGUILayout.EndHorizontal();
			if (target.EnableCameraLayerCulling) {
				target.SmallDetailsDistance = EditorGUILayout.Slider("Small Detail Distance", target.SmallDetailsDistance, 10.0, 300.0);
				target.MediumDetailsDistance = EditorGUILayout.Slider("Medium Detail Distance", target.MediumDetailsDistance, 10.0, 300.0);
			}
		}
		EditorGUILayout.EndVertical();
		
	//	Special Render Settings
		GUILayout.Space(4);
		EditorGUILayout.BeginVertical("Box");
		GUI.color = myCol;
		target.FoldRender = EditorGUILayout.Foldout(target.FoldRender," Special Render Settings", myFoldoutStyle );
		GUI.color = Color.white;
		if (target.FoldRender) {
			EditorGUILayout.BeginHorizontal();
			target.AllGrassObjectsCombined = EditorGUILayout.Toggle("", target.AllGrassObjectsCombined, GUILayout.Width(14) );
			EditorGUILayout.LabelField("All Grass Objects Combined");
			EditorGUILayout.EndHorizontal();
		}
		EditorGUILayout.EndVertical();
		
		GUILayout.Space(4);
		
		// update settings // we have to call it constantly to make the grass shaders work
		if (GUI.changed) {
			target.Update();
			SceneView.RepaintAll();
		}
		
	}
	
	
	function ResetBillboardFadeLength () {
		var allTerrains : Terrain[] = FindObjectsOfType(Terrain) as Terrain[];
		
		for (i = 0; i < allTerrains.Length; i ++) {
			allTerrains[i].treeCrossFadeLength = 0;
		}
	
	}
	
	function RestoreBillboardFadeLength (resetValue : float) {
		var allTerrains : Terrain[] = FindObjectsOfType(Terrain) as Terrain[];
		
		for (i = 0; i < allTerrains.Length; i ++) {
			allTerrains[i].treeCrossFadeLength = resetValue;
		}
	
	}
	
}
#endif
