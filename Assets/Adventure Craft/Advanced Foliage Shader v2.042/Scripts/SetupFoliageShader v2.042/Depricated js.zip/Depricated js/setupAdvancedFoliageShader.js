// setupAdvancedFoliageShader v. 2.042
// See: documentation SetupFoliageShader.rtf for further details

@script ExecuteInEditMode() // update is called by the custom editor


#if UNITY_EDITOR
//	Editor Variables
var newEditor : boolean = true;
var FoldWind : boolean = false;
var FoldRain : boolean = false;
var FoldGrass : boolean = false;
var FoldVegTerrain : boolean = false;
var FoldBillboard : boolean = false;
var FoldCulling : boolean = false;
var FoldRender : boolean = false;
#endif

//
//	Wind parameters which are needed by all shaders
var Wind : Vector4 = Vector4(0.85,0.075,0.4,0.5);
var WindFrequency = 0.75;
var WaveSizeFoliageShader = 10;
//	Wind parameters only needed by the advanced grass shaders
var WindMultiplierForGrassshader = 1.00;
var WaveSizeForGrassshader = 10;
//
//	Rain Settings
var RainAmount	= 0.0;
var SpecPower = 1.0;

//
//	Terrain Detail Vegetation Settings
var VertexLitAlphaCutOff = 0.3;
var VertexLitTranslucencyColor : Color = Color(0.73,0.85,0.4,1);
var VertexLitTranslucencyViewDependency = 0.7;
var VertexLitShadowStrength = 0.8;
var VertexLitShininess = 0.2;

//
//	Grass, Tree and Billboard settings
var AutoSyncToTerrain = false;
var SyncedTerrain : Terrain;
var AutoSyncInPlaymode = false;
var DetailDistanceForGrassShader = 80;
var BillboardStart = 50.0;
var BillboardFadeLenght = 5.0;

//	Tree Render settings
var TreeShadowDissolve = false;
var TreeBillboardShadows = false;
var BillboardFadeOutLength = 60;
var BillboardAdjustToCamera = true;
var BillboardAngleLimit = 30;

//	Billboard Render Tex settings
var BillboardTranslucencyFactor = 1.8;
var BillboardLeafsLightingFactor = 2.13;
var BillboardLeafsContrast = 1.05;

//	"Shaded" Billboard settings
var BillboardLightReference : GameObject;
var BillboardShadowColor : Color;
var BillboardAmbientLightFactor = 1.0;
var BillboardAmbientLightDesaturationFactor = 0.7;

//
//	Camera Layer Culling Settings
var EnableCameraLayerCulling = true;
var SmallDetailsDistance = 70;
var MediumDetailsDistance = 90;

//
//	Special Render Settings
var AllGrassObjectsCombined = false;

function Awake ()
{
//
//	Wind Settings
	Shader.SetGlobalVector("_Wind", Wind);
	Shader.SetGlobalFloat("_AfsWaveSize", WaveSizeFoliageShader);
	// wind animation for the grass shader on manually placed game objects: wind speed, wave size, wind amount, max sqr distance
	var GrassWind = (Wind.x + Wind.z) / 2;
	Shader.SetGlobalVector("_AfsWaveAndDistance", Vector4( UnityEngine.Time.time * (WindFrequency * 0.05) , (0.5 / WaveSizeForGrassshader ), GrassWind * WindMultiplierForGrassshader, (DetailDistanceForGrassShader + 10) * (DetailDistanceForGrassShader + 10)) );
	
//
//	Rain Settings
	Shader.SetGlobalFloat("_AfsRainamount", RainAmount);
	Shader.SetGlobalFloat("_AfsSpecPower", SpecPower);

//
//	Terrain Detail Vegetation Settings
	Shader.SetGlobalFloat("_AfsAlphaCutOff", VertexLitAlphaCutOff);
	VertexLitShininess = Mathf.Clamp(VertexLitShininess, 0.03, 1.0);
	Shader.SetGlobalFloat("_AfsShininess", VertexLitShininess);
	Shader.SetGlobalColor("_AfsTranslucencyColor", VertexLitTranslucencyColor);
	Shader.SetGlobalFloat("_AfsTranslucencyViewDependency", VertexLitTranslucencyViewDependency);
	Shader.SetGlobalFloat("_AfsShadowStrength", VertexLitShadowStrength);
	Shader.SetGlobalFloat("_ShadowOffsetScale", 1.0);
	// windows bugfix for the "advancedFoliageShader for Terrainengine" shader
	if (Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.WindowsWebPlayer || Application.platform == RuntimePlatform.WindowsEditor ) {
		Shader.SetGlobalFloat("_Windows", 1.0);	
	}
	else {
		Shader.SetGlobalFloat("_Windows", 0.0);	
	}
	
//
//	Grass, Tree and Billboard Settings
	// DetailDistanceForGrassShader has already been passed with: _AfsWaveAndDistance
	Shader.SetGlobalVector("_AfsTerrainTrees", Vector4(BillboardStart, BillboardFadeLenght, BillboardFadeOutLength, 0 ));
	if(TreeShadowDissolve) {
		Shader.EnableKeyword("TREE_SHADOW_DISSOLVE");
		Shader.DisableKeyword("TREE_SHADOW_NO_DISSOLVE");
	}
	else {
		Shader.EnableKeyword("TREE_SHADOW_NO_DISSOLVE");
		Shader.DisableKeyword("TREE_SHADOW_DISSOLVE");
	}
	if(TreeBillboardShadows) {
		Shader.EnableKeyword("BILLBOARD_SHADOWS");
		Shader.DisableKeyword("BILLBOARD_NO_SHADOWS");
	}
	else {
		Shader.EnableKeyword("BILLBOARD_NO_SHADOWS");
		Shader.DisableKeyword("BILLBOARD_SHADOWS");
	}
	//	Billboard Texture Settings
	Shader.SetGlobalVector("_AfsBillboardAdjustments", Vector4( 1, BillboardTranslucencyFactor, BillboardLeafsLightingFactor, BillboardLeafsContrast));
	//	Camera Settings for the Billboard Shader
	var CameraForward : Vector3 = Vector3(0, 0, 0);
	var SahdowCameraForward : Vector3 = Vector3(0, 0, 0);
	var rollingX : float;
	var rollingXShadow : float;
	if (Camera.main) {
		CameraForward = Camera.main.transform.forward;
		ShadowCameraForward = CameraForward;
		rollingX = Camera.main.transform.eulerAngles.x;
	}
	else {
		Debug.Log("You have to tag your Camera as MainCamera");
	}
	if(BillboardAdjustToCamera) {
		if (rollingX >= 270.0) {					// looking up
			rollingX = (rollingX - 270.0);
			rollingX = (90.0 - rollingX);
			rollingXShadow = rollingX;
		}
		else {										// looking down
			rollingXShadow = -rollingX;
			if (rollingX > BillboardAngleLimit) {
				// from the first demo:
				//rollingX = Mathf.Lerp(rollingX, 0, (rollingX - 30)/45 ); 
				rollingX = Mathf.Lerp(rollingX, 0,  (rollingX / BillboardAngleLimit) - 1 );
			}
			rollingX *= -1;
		}
	}
	else {
		rollingX = 0;
		rollingXShadow = 0;
	}
	CameraForward *= rollingX / 90.0;
	ShadowCameraForward *= rollingXShadow / 90.0;
	Shader.SetGlobalVector("_AfsBillboardCameraForward", Vector4( CameraForward.x, CameraForward.y, CameraForward.z, 1));
	Shader.SetGlobalVector("_AfsBillboardShadowCameraForward", Vector4( ShadowCameraForward.x, ShadowCameraForward.y, ShadowCameraForward.z, 1));
	// Set lightDir for Billboard Shadows
	if (BillboardLightReference != null) {
		var lightDir : Vector3 = BillboardLightReference.transform.forward;
		var templightDir : Vector3 = lightDir;
		lightDir = Vector3.Cross(lightDir, Vector3.up);
	
		// flipp lightDir if camera is aligned with light
		if (Vector3.Dot(templightDir, Camera.main.transform.forward) > 0) {
			lightDir = Quaternion.AngleAxis(180, Vector3.up) * lightDir;
		}
		Shader.SetGlobalVector("_AfsSunDirection", Vector4(lightDir.x, lightDir.y, lightDir.z, 1) );
	}
//	
	else {
		Debug.LogWarning("You have to specify a Light Reference!");
	}

	//	Set desaturated ambient light for shaded billboards
	BillboardShadowColor = RenderSettings.ambientLight;
	BillboardShadowColor = Desaturate(BillboardShadowColor.r * BillboardAmbientLightFactor, BillboardShadowColor.g * BillboardAmbientLightFactor, BillboardShadowColor.b * BillboardAmbientLightFactor);
	if (BillboardLightReference) {
		BillboardShadowColor += 0.5 * (BillboardShadowColor * (1 - BillboardLightReference.light.shadowStrength));
	}
	Shader.SetGlobalColor("_AfsAmbientBillboardLight", BillboardShadowColor );
	
//
//	Camera Layer Culling Settings
	if(EnableCameraLayerCulling) { 
		for (i = 0; i < Camera.allCameras.Length; i++) {
			var distances = new float[32];
			distances = Camera.allCameras[i].layerCullDistances;
			distances[8] = SmallDetailsDistance; // small things like DetailDistance of the terrain engine
			distances[9] = MediumDetailsDistance; // small things like DetailDistance of the terrain engine
			Camera.allCameras[i].layerCullDistances = distances;
		}
	}
}

function Start ()
{
//
//	Camera Layer Culling Settings
	if(EnableCameraLayerCulling) { 
		for (i = 0; i < Camera.allCameras.Length; i++) {
			var distances = new float[32];
			distances = Camera.allCameras[i].layerCullDistances;
			distances[8] = SmallDetailsDistance; // small things like DetailDistance of the terrain engine
			distances[9] = MediumDetailsDistance; // small things like DetailDistance of the terrain engine
			Camera.allCameras[i].layerCullDistances = distances;
		}
	}
//
//	Special Render Settings
	//Tell the "advancedGrassShader Groundlighting" to lit the objects based on baked normals
	Shader.EnableKeyword("IN_PLAYMODE");
	Shader.DisableKeyword("IN_EDITMODE");
}

public function Update () {

	#if UNITY_EDITOR
	//	Special Render Settings	
		//	Tell the "advancedGrassShader Groundlighting" how to lit the objects
		if (Application.isPlaying || AllGrassObjectsCombined) {
			// Lighting based on baked normals
			Shader.DisableKeyword("IN_EDITMODE");
			Shader.EnableKeyword("IN_PLAYMODE");
		}
		else {
			// Lighting according to rotation
			Shader.DisableKeyword("IN_PLAYMODE");
			Shader.EnableKeyword("IN_EDITMODE");
		}
	//	Terrain engine settings
		//VertexLitShininess = Mathf.Clamp(VertexLitShininess, 0.03, 1.0);
		Shader.SetGlobalFloat("_AfsAlphaCutOff", VertexLitAlphaCutOff);
		Shader.SetGlobalColor("_AfsTranslucencyColor", VertexLitTranslucencyColor);
		Shader.SetGlobalFloat("_AfsTranslucencyViewDependency", VertexLitTranslucencyViewDependency);
		Shader.SetGlobalFloat("_AfsShadowStrength", VertexLitShadowStrength);
		Shader.SetGlobalFloat("_AfsShininess", VertexLitShininess);
	#endif
	
//
//	Terrain engine settings	
	//Enable the following lines only in case you need to update these values at runtime
	//VertexLitShininess = Mathf.Clamp(VertexLitShininess, 0.03, 1.0);
	//Shader.SetGlobalFloat("_AfsAlphaCutOff", VertexLitAlphaCutOff);
	//Shader.SetGlobalColor("_AfsTranslucencyColor", VertexLitTranslucencyColor);
	//Shader.SetGlobalFloat("_AfsTranslucencyViewDependency", VertexLitTranslucencyViewDependency);
	//Shader.SetGlobalFloat("_AfsShadowStrength", VertexLitShadowStrength);
	//Shader.SetGlobalFloat("_AfsShininess", VertexLitShininess);
	//Shader.SetGlobalVector("_AfsTerrainTrees", Vector4(TerrainBillboardStart, TerrainBillboardFadeLenght, 0, 0 ));

//
//	Update Wind Settings
	// Simple wind animation for the foliage shaders
	var TempWind : Vector4 = Wind;
	var TempWindForce = Wind.w;
	TempWind.x *= (1.25 + Mathf.Sin(UnityEngine.Time.time * WindFrequency) * Mathf.Sin(UnityEngine.Time.time * 0.375)) * 0.5;
	TempWind.z *= (1.25 + Mathf.Sin(UnityEngine.Time.time * WindFrequency) * Mathf.Sin(UnityEngine.Time.time * 0.193)) * 0.5;
	TempWind.w = TempWindForce;
	Shader.SetGlobalVector("_Wind", TempWind);
	var GrassWind = (TempWind.x + TempWind.z) / 2;
	Shader.SetGlobalFloat("_AfsWaveSize", (0.5 / WaveSizeFoliageShader) );
	// Wind animation for the grass shader on manually placed game objects: wind speed, wave size, wind amount, max pow2 distance
	Shader.SetGlobalVector("_AfsWaveAndDistance", Vector4( UnityEngine.Time.time * (WindFrequency * 0.05) , (0.5 / WaveSizeForGrassshader ), GrassWind * WindMultiplierForGrassshader, (DetailDistanceForGrassShader + 10) * (DetailDistanceForGrassShader + 10)) );
			
//
//	Update Rain Settings
	Shader.SetGlobalFloat("_AfsRainamount", RainAmount);
	Shader.SetGlobalFloat("_AfsSpecPower", SpecPower);

//
//	AutoSyncToTerrain
	if(AutoSyncToTerrain && SyncedTerrain != null) {
		DetailDistanceForGrassShader = SyncedTerrain.detailObjectDistance;
		BillboardStart = SyncedTerrain.treeBillboardDistance;
		if(!TreeBillboardShadows) {
			BillboardFadeLenght = SyncedTerrain.treeCrossFadeLength;
		}
	}
			
//	Grass, Tree and Billboard Settings
	// DetailDistanceForGrassShader has already been passed with: _AfsWaveAndDistance
	Shader.SetGlobalVector("_AfsTerrainTrees", Vector4(BillboardStart, BillboardFadeLenght, BillboardFadeOutLength, 0 ));
	if(TreeShadowDissolve) {
		Shader.EnableKeyword("TREE_SHADOW_DISSOLVE");
		Shader.DisableKeyword("TREE_SHADOW_NO_DISSOLVE");
	}
	else {
		Shader.EnableKeyword("TREE_SHADOW_NO_DISSOLVE");
		Shader.DisableKeyword("TREE_SHADOW_DISSOLVE");
	}
	if(TreeBillboardShadows) {
		Shader.EnableKeyword("BILLBOARD_SHADOWS");
		Shader.DisableKeyword("BILLBOARD_NO_SHADOWS");
	}
	else {
		Shader.EnableKeyword("BILLBOARD_NO_SHADOWS");
		Shader.DisableKeyword("BILLBOARD_SHADOWS");
	}
	//	Billboard Texture Settings
	Shader.SetGlobalVector("_AfsBillboardAdjustments", Vector4( 1, BillboardTranslucencyFactor, BillboardLeafsLightingFactor, BillboardLeafsContrast));
	//	Camera Settings for the Billboard Shader
	var CameraForward : Vector3 = Vector3(0, 0, 0);
	var SahdowCameraForward : Vector3 = Vector3(0, 0, 0);
	var rollingX : float;
	var rollingXShadow : float;
	//if (Camera.current && Application.isPlaying) {
	//	CameraForward = Camera.current.transform.forward;
	//	rollingX = Camera.current.transform.eulerAngles.x;
	//}
	//else {
	if (Camera.main) {
		CameraForward = Camera.main.transform.forward;
		ShadowCameraForward = CameraForward;
		rollingX = Camera.main.transform.eulerAngles.x;
	}
	else {
		Debug.Log("You have to tag your Camera as MainCamera");
	}
	//}
	if(BillboardAdjustToCamera) {
		if (rollingX >= 270.0) {					// looking up
			rollingX = (rollingX - 270.0);
			rollingX = (90.0 - rollingX);
			rollingXShadow = rollingX;
		}
		else {										// looking down
			rollingXShadow = -rollingX;
			if (rollingX > BillboardAngleLimit) {
				// from the first demo:
				//rollingX = Mathf.Lerp(rollingX, 0, (rollingX - 30)/45 ); 
				rollingX = Mathf.Lerp(rollingX, 0,  (rollingX / BillboardAngleLimit) - 1 );
			}
			rollingX *= -1;
		}
	}
	else {
		rollingX = 0;
		rollingXShadow = 0;
	}
	CameraForward *= rollingX / 90.0;
	ShadowCameraForward *= rollingXShadow / 90.0;
	Shader.SetGlobalVector("_AfsBillboardCameraForward", Vector4( CameraForward.x, CameraForward.y, CameraForward.z, 1));
	Shader.SetGlobalVector("_AfsBillboardShadowCameraForward", Vector4( ShadowCameraForward.x, ShadowCameraForward.y, ShadowCameraForward.z, 1));
	// Set lightDir for Billboard Shadows
	if (BillboardLightReference != null) {
		var lightDir : Vector3 = BillboardLightReference.transform.forward;
		var templightDir : Vector3 = lightDir;
		lightDir = Vector3.Cross(lightDir, Vector3.up);
		// flipp lightDir if camera is aligned with light
		if (Vector3.Dot(templightDir, Camera.main.transform.forward) > 0) {
			lightDir = Quaternion.AngleAxis(180, Vector3.up) * lightDir;
		}
		Shader.SetGlobalVector("_AfsSunDirection", Vector4(lightDir.x, lightDir.y, lightDir.z, 1) );
	}
	//	
	else {
		Debug.LogWarning("You have to specify a Light Reference!");
	}
	
	//	Set desaturated ambient light for shaded billboards
	BillboardShadowColor = RenderSettings.ambientLight;
	BillboardShadowColor = Desaturate(BillboardShadowColor.r * BillboardAmbientLightFactor, BillboardShadowColor.g * BillboardAmbientLightFactor, BillboardShadowColor.b * BillboardAmbientLightFactor);
	if (BillboardLightReference) {
		BillboardShadowColor += 0.5 * (BillboardShadowColor * (1 - BillboardLightReference.light.shadowStrength));
	}
	Shader.SetGlobalColor("_AfsAmbientBillboardLight", BillboardShadowColor );
		
}

//
//	Helper functions
function Desaturate(r : float, g : float, b : float) : Color {
	var grey : float = 0.3 * r + 0.59 * g + 0.11 * b;
	r = grey * BillboardAmbientLightDesaturationFactor + r * (1 - BillboardAmbientLightDesaturationFactor);
	g = grey * BillboardAmbientLightDesaturationFactor + g * (1 - BillboardAmbientLightDesaturationFactor);
	b = grey * BillboardAmbientLightDesaturationFactor + b * (1 - BillboardAmbientLightDesaturationFactor);
	return (Color(r, g, b, 1.0));
}
